from django.apps import AppConfig


class SamuelscrumyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'samuelscrumy'
